import java.util.Scanner;
class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MZFecha b = new MZFecha();

        int opcion, dia = 0, mes = 0, anyo = 0, diferencia = 0;
        do {
        System.out.println("Elige una opción:");
        System.out.println("1. Establecer fecha.");
        System.out.println("2. Imprimir fecha.");
        System.out.println("3. Diferenciar dos fechas.");
        System.out.println("4. Salir.");
        opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Introduce el dia:");
                    dia = sc.nextInt();
                    System.out.println("Introduce el mes:");
                    mes = sc.nextInt();
                    System.out.println("Introduce el anyo:");
                    anyo = sc.nextInt();
                    b.setFecha(dia, mes, anyo);
                    break;
                case 2:
                    b.comprueba(dia, mes, anyo);
                    b.imprime();
                    break;
                case 3:
                    System.out.println("Introduce el dia:");
                    dia = sc.nextInt();
                    System.out.println("Introduce el mes:");
                    mes = sc.nextInt();
                    System.out.println("Introduce el anyo:");
                    anyo = sc.nextInt();
                    b.setFecha(dia, mes, anyo);
                    diferencia = b.diasdesdeInicio();
                    System.out.println("La diferencia de dias es de " + diferencia + " dias.");
                    break;
                case 4:
                    System.out.println("Se ha cerrado el programa.");
                    break;
            }
        } while (opcion != 4);
    }
}
